/*! ramp-theme-usability Plugins 05-06-2015 18:24:18 : v. 5.4.0 
 * 
 * RAMP GIS viewer - Groundhog; Sample of an implementation of RAMP with Usability Theme 
 **/
RAMP.plugins.featureInfoParser.jsonRawParse=function(a){"use strict";return"<p>{0}</p>".format(a)};