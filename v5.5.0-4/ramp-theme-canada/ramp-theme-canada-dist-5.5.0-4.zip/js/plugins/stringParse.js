/*! ramp-theme-canada Plugins 12-06-2015 14:13:18 : v. 5.5.0-4 
 * 
 * RAMP GIS viewer - Groundhog; Sample of an implementation of RAMP with Canada.ca Theme 
 **/
RAMP.plugins.featureInfoParser.stringParse=function(a){"use strict";return"<p>{0}</p>".format(a)};