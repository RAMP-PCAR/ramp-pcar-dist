/*! ramp-theme-fgp-int Plugins 11-06-2015 22:35:46 : v. 5.5.0-3 
 * 
 * RAMP GIS viewer - Groundhog; Sample of an implementation of RAMP with Intranet Theme 
 **/
RAMP.plugins.featureInfoParser.stringParse=function(a){"use strict";return"<p>{0}</p>".format(a)};