/*! ramp-theme-fgp-int Plugins 05-06-2015 12:01:45 : v. 5.4.0-rc3 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP with Intranet Theme 
 **/
RAMP.plugins.featureInfoParser.stringParse=function(a){"use strict";return"<p>{0}</p>".format(a)};