/*! ramp-theme-fgp-int Plugins 10-07-2015 14:25:18 : v. 5.5.0-9 
 * 
 * RAMP GIS viewer - Groundhog; Sample of an implementation of RAMP with Intranet Theme 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};