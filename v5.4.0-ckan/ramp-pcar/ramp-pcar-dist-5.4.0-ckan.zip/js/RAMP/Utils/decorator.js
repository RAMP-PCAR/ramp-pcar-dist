/*! ramp-pcar 10-06-2015 17:23:52 : v. 5.4.0-ckan 
 * 
 * RAMP GIS viewer - Groundhog; Sample of an implementation of RAMP 
 **/
define([],function(){"use strict";return{getFindFcn:function(a,b){function c(c){return a(b,c)}return c}}});