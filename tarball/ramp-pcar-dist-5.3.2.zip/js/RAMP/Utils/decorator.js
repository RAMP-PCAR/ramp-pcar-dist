/*! ramp-pcar 21-05-2015 18:11:18 : v. 5.3.2 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP 
 **/
define([],function(){"use strict";return{getFindFcn:function(a,b){function c(c){return a(b,c)}return c}}});