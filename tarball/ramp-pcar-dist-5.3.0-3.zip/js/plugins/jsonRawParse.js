/*! ramp-pcar Plugins 06-05-2015 17:45:09 : v. 5.3.0-3 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP 
 **/
RAMP.plugins.featureInfoParser.jsonRawParse=function(a){"use strict";return"<p>{0}</p>".format(a)};