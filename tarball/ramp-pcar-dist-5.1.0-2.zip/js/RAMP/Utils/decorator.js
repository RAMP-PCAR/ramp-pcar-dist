/*! ramp-pcar 02-03-2015 17:06:40 : v. 5.1.0-2 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP 
 **/
define([],function(){"use strict";return{getFindFcn:function(a,b){function c(c){return a(b,c)}return c}}});