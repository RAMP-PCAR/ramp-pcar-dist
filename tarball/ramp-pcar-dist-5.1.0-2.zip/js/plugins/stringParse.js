/*! ramp-pcar Plugins 02-03-2015 17:06:59 : v. 5.1.0-2 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP 
 **/
RAMP.plugins.featureInfoParser.stringParse=function(a){"use strict";return"<p>{0}</p>".format(a)};