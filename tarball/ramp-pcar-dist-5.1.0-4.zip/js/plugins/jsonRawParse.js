/*! ramp-pcar Plugins 19-03-2015 16:31:32 : v. 5.1.0-4 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP 
 **/
RAMP.plugins.featureInfoParser.jsonRawParse=function(a){"use strict";return"<p>{0}</p>".format(a)};