/*! ramp-pcar Plugins 25-03-2015 19:16:27 : v. 5.2.0-rc2 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};