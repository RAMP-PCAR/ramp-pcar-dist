/*! ramp-pcar Plugins 31-03-2015 19:54:19 : v. 5.2.0 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP 
 **/
RAMP.plugins.featureInfoParser.stringParse=function(a){"use strict";return"<p>{0}</p>".format(a)};