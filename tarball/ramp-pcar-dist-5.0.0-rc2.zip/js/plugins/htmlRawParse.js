/*! ramp-pcar Plugins 11-02-2015 13:48:32 : v. 5.0.0-rc2 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};