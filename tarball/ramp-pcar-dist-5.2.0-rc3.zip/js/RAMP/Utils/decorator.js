/*! ramp-pcar 26-03-2015 18:26:26 : v. 5.2.0-rc3 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP 
 **/
define([],function(){"use strict";return{getFindFcn:function(a,b){function c(c){return a(b,c)}return c}}});