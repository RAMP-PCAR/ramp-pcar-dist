/*! ramp-pcar 31-03-2015 16:17:32 : v. 5.2.0-rc7 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP 
 **/
define([],function(){"use strict";return{getFindFcn:function(a,b){function c(c){return a(b,c)}return c}}});