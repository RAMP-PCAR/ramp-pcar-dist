/*! ramp-pcar Plugins 23-01-2015 18:34:13 : v. 5.0.0-10 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP 
 **/
RAMP.plugins.featureInfoParser.stringParse=function(a){"use strict";return"<p>{0}</p>".format(a)};