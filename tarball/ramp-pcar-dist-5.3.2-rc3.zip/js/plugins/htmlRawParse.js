/*! ramp-pcar Plugins 21-05-2015 14:27:37 : v. 5.3.2-rc3 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};