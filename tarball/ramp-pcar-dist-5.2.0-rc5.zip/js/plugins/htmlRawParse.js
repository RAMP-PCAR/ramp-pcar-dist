/*! ramp-pcar Plugins 27-03-2015 18:13:30 : v. 5.2.0-rc5 
 * 
 * RAMP GIS viewer - Elk; Sample of an implementation of RAMP 
 **/
RAMP.plugins.featureInfoParser.htmlRawParse=function(a){"use strict";return"{0}".format(a)};